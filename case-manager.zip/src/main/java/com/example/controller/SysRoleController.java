package com.example.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author Relief
 * @since 2025-04-09
 */
@Controller
@RequestMapping("/sysRole")
public class SysRoleController {

}
