package com.example.mapper;

import com.example.entity.SysUserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Relief
 * @since 2025-04-09
 */
public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {

}
