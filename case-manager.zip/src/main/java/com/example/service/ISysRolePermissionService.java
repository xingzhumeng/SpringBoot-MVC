package com.example.service;

import com.example.entity.SysRolePermission;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Relief
 * @since 2025-04-09
 */
public interface ISysRolePermissionService extends IService<SysRolePermission> {

}
